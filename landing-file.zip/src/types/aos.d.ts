declare module "aos";
