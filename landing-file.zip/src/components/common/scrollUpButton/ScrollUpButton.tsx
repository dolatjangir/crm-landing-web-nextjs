"use client"
import { useState, useEffect } from "react"
import { FiArrowUp } from "react-icons/fi"


function ScrollUpButton() {
    const [visible, setVisible] = useState(false);
    useEffect(() => {
        const togglevisibility = () => {
            if (window.scrollY > 300) {
                setVisible(true);}
                else{
                    setVisible(false);
                }
                };
                window.addEventListener("scroll", togglevisibility);
                return () => window. removeEventListener("scroll", togglevisibility);
            
            }, []);
            const scrollToTop = () =>{
                window.scrollTo({
                    top:0,
                    behavior:"smooth",
                });
            }

  return (
    
     <button
      onClick={scrollToTop}
      aria-label="Scroll to top"
      className={`
        fixed bottom-8 right-8 z-[999]
        flex items-center justify-center
        w-12 h-12 rounded-full
        bg-white  text-blue-600
   shadow-[-3px_-3px_6px_rgba(255,255,255,0.9),3px_3px_6px_rgba(0,0,0,0.35)]
   
        transition-all duration-300 ease-in-out
         hover:scale-105
       
        ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"}
      `}
    > <span
    className="
      pointer-events-none
      absolute inset-1 rounded-full

      /* INNER INSET SHADOW */
      shadow-[inset_2px_2px_2px_rgba(0,0,0,0.35),inset_2px_2px_4px_rgba(255,255,255,0.6)]
    "
  />
       
      <FiArrowUp className="animate-bounce " size={24} />
    </button>
  )
}

export default ScrollUpButton
